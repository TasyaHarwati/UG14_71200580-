package com.ug14.rumahsakit;

public class Jadwal {
}
